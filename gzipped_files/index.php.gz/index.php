<?php include_once('inc/gzip.php') ?>
<html>
<head>
<SCRIPT>
// Get out of someone's frames
if (window.top != self) top.location.href = self.location.href;
</SCRIPT>
<title>Global Solutions Home Page - Global Solutions - An Internet Community Takes On Globalisation Writing An Online Book</title>
<meta name="description" content="Exchanging ideas on sustainable living and development. Participate in an online discussion. Download FREE eBOOK!">
<meta name="keywords" content="globalisation,civic,civil,reform,book,online,democracy,government,governance,fairness,freedom,equality,capitalism,neo-liberalism,economy,monetary,money,spirituality,politics,corporations,media,information,sustainability,earth,environment,pollution,food,safety,citizenship,citizen,community,education,homeschooling,learning,centres,centers,globalization,multinationals,NGO,GRO,grassroots,IMF,GATT,NAFTA,Worldbank,UN,LETS,consumerism,progress,anti-globalist,action,act now">
<meta name="robots" content="all">
<meta name="robots" content="index,follow">
<meta http-equiv="author" content="Adriaan Boiten / Aideon">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>

<script language="JavaScript">
<!--
var FirstForm;
         function StartSearch(){
            document.forms[FirstForm+document.InputForm.SearchSelect.
             selectedIndex].elements[0].value=document.InputForm.SearchWords.value;
            document.forms[FirstForm+document.InputForm.SearchSelect.
         selectedIndex].submit();
         }
// -->
</script>

<script language="JavaScript">
<!--
<!--
FirstForm=document.forms.length
// -->

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>

<style>
a{text-decoration:none}
a:hover{text-decoration: underline; color:#CC3300;}
TD          { font-family:  Verdana, Arial, Helvetica, sans-serif;}
</style>

</head>

<body bgcolor="#ADAD85" text="#000000" link="#003333" vlink="#006666" alink="#006666">

  <table width="750" border="1" cellpadding="5" cellspacing="0" bordercolor="#666666" bgcolor="#FFFFF4">
    <tr bgcolor="#FFFFFf">
      <td width="750" height="300" colspan="6">                <div align="center">
            <img src="ebooklogo.jpg" width="462" height="152">
            <p><font face="Times New Roman, Times, serif" size="7" color="#CC3300">G</font><font face="Times New Roman, Times, serif" size="7">LOBAL <font color="#CC3300">S<font color="#000000">OLUTIONS</font></font></font></p>
            <p><font size="3" face="Times New Roman, Times, serif"><font size="5"><strong><font color="#009933" size="3" face="Verdana, Arial, Helvetica, sans-serif">An
                        Internet Community Takes On Globalisation</font></strong></font></font></p>
            <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Exchanging
                  ideas on sustainable living and development at the <a href="http://groups.yahoo.com/group/FixGov" target="_blank"><font color="#CC3300">FixGov
                Discussion Board</font></a></b></font></p>
            <hr align="center" width="725">
          <table width="720" border="0" align="center" cellpadding="5" cellspacing="0">
            <tr>
                <td width="240" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><a href="http://www.protest.net" target="top"><font color="#CC3300" size="1">Next
                          global action</font></a></b><font size="1"><br>
  Take on to the next global stage.<br>
  A comprehensive calendar of protest, meetings and conferences. Also a link to
  vigils, meetings, teach-in's calling for justice, not war after September 11.<b> <a href="http://www.protest.net" target="top"><font color="#CC3300">>>></font></a></b> </font></font></td>
                <td width="240" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#CC0000"><b><a href="http://www.globalissues.org" target="_blank"><font color="#CC3300" size="1">What
                          is globalisation?</font></a></b></font><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
  Make up your mind and start to think about the current one-sided economic globalisation
  and the need for a more balanced global civic reform. <strong>Global Issues</strong> ...<b><a href="http://www.globalissues.org" target="_blank"><font color="#CC3300">>>></font></a></b> </font></td>
                <td width="240" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><a href="http://www.simpol.org" target="top"><font color="#CC3300" size="1">A
                          New Democracy</font></a></b><font size="1"><br>
  Are we helpless or can we do something: building an equitable, cooperative and
  sustainable future through global political consensus? <b><a href="http://www.simpol.org" target="top"><font color="#CC3300">>>></font></a></b> </font></font></td>
            </tr>
              <tr>
                <td height="60" valign="middle"><font color="#CC3300" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong><a href="download.html"><img src="cover.jpg" alt="Download page" width="33" height="50" border="1" align="absmiddle"></a> �DOWNLOAD
                     eBOOK FOR FREE!</strong></font></td>
                <td height="60"><font color="#CC3300" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>                EXTRA:
                      FREE DOWNLOAD > <a href="numbers.html"><img src="playcover1.jpg" alt="Richard Stimson" width="36" height="50" border="1" align="absmiddle"></a></strong></font></td>
                <td height="60"><font color="#CC3300" size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>              FREE
                      eBooks that make you think!</strong></font></td>
            </tr>
          </table>
      </div></td></tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CCCCCC"><font color="#CC3300" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Home</strong></font></td>
      <td width="125" rowspan="15" valign="top" bgcolor="#CCCCCC"><p><font face="Verdana, Arial, Helvetica, sans-serif" size="3" color="#CC3300"><b>Welcome!</b></font> </p>
        <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#000000">This
              site is the result of an ongoing discussion at the <a href="http://groups.yahoo.com/group/FixGov" target="top"><font color="#CC3300">FixGov
              discussion group</font></a> (since August 2000).</font></b></p>
        <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#000000">The
              members of this group have made and discussed drafts about the
              seven subjects you see at the left.</font></b></p>
        <p><b><font color="#000000" size="1" face="Verdana, Arial, Helvetica, sans-serif">All
              these discussions have led to the editing of a <a href="download.html"><font color="#CC3300">book</font></a> on
              globalisation, aimed at giving some practical hand-outs to act
      upon the challenges.</font></b></p>
      <p align="center"><b><font color="#000000" size="1" face="Verdana, Arial, Helvetica, sans-serif">______________</font></b></p>
      <p align="left"><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="1"><b>At
            this site we will present the several drafts and proposals to change
        our world in a positive, sustainable way</b></font></p>
      <p><b><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="1">We
            invite you to join the ongoing discussions. Or join the global action.</font></b></p>
      <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#000000">We
            promote true understanding through the disseminaton of valuable information
      and <a href="http://www.lib.umich.edu/govdocs/index.html" target="top"><font color="#CC3300">resources</font></a>.</font></b></p>
      <p align="center"><b><font color="#000000" size="1" face="Verdana, Arial, Helvetica, sans-serif">______________</font></b></p>
      <p align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Links:</strong></font></p>
      <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#CC3300"><b><font size="1">1. <a href="http://www.globalissues.org/" target="top"><font color="#CC3300">Global
                  Issues That Affect Everyone</font></a><br>
2. <a href="http://www.alternet.org/issues/index.html?IssueAreaID=21" target="top"><font color="#CC3300">AlterNet.org
-- Globalization</font></a><br>
3. <a href="http://www.corpwatch.org/" target="top"><font color="#CC3300">CorpWatch</font></a><br>
4. <a href="http://www.ems.org/" target="top"><font color="#CC3300">Environmental
Media Services</font></a><br>
5. <a href="http://www.hrw.org/" target="top"><font color="#CC3300">Human Rights
Watch</font></a></font></b></font></p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p align="left">�</p>
      <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1">original
            proposal: <font color="#CC3300">Adriaan Boiten</font> (based upon
            John Rawls' <i>Justice As Fairness</i>) >>></font></b></p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>
      <p>�</p>      <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#000000">_________________</font></b></p>
      <p><a href="http://groups.yahoo.com/group/FixGov/join" target="top"> <img src="join.gif" border=0></a></p>
      <p><a href="http://groups.yahoo.com/group/FixGov/join" target="top"> <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#000000">Click
              to subscribe to FixGov</font></b></a></p>
      </td>
      <td width="500" colspan="4" rowspan="16" valign="top"><p><font face="Verdana, Arial, Helvetica, sans-serif" size="3"><b><font color="#CC0033" size="4">F</font>ixing
              Government & Governance</b></font></p>
        <p> <font face="Verdana, Arial, Helvetica, sans-serif" size="2">FixGov
            aims to promote economic, ecological, and social justice. We are
            working on this site about government reform and we hope for ideas
            from many areas of the world. </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2">The
            FixGov group exists because all the efforts individuals make for
            sustainable living can be offset by corporate and government decisions.
            How can local, national, and international governments be made answerable
            to the people they govern instead of just the power elites? </font></p>
        <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2">When major
            polluters of the atmosphere use political muscle to escape environmental
            controls, what can be done by the people who have to breathe the
            polluted air? When municipal sewage dumping or industrial waste fouls
            water that is vital to human health, how can people protect themselves?
            When large-scale corporate agriculture and food processing distribute
            contaminated food and make consumers unknowing guinea pigs for genetic
            modification, radiation, and dangerous substances, how can they be
            subjected to effective control? </font></p>
        <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Join a
            discussion seeking ways to overcome the corruption that undermines
            public interest throughout the world, overthrowing or blocking democracy
            in some countries, making voting seem futile to many in the US, and
            secretly controlling such UN agencies as WTO, IMF, and the World
      Bank.</font></p>
      <p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">_____________________________________________</font></p>
      <p align="left"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a name="book"></a></font></p>
      <p><font size="3" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#CC0033" size="4">A</font> Blueprint
            for Action in the Global Age</strong></font></p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">At the forum
          we're acting also. We're not just discussing on global issues, but
          also engaging ourselves in a consensus process, aimed at writing a
          book with proposals and solutions.</font></p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">The origin
          of this online book is therefore quite unusual. Most books have one
          author, sometimes two, but this book is the product of collaboration
          by a large number of people in many countries participating in an Internet
          forum. Defying the adage that the only piece of good writing by committee
          was the King James Version of the Bible, the members of this forum
          set out to create a guide for reform of government at all levels from
          global down to local communities, and especially to counter global
          control by financial interests at the expense of democratic self-rule.</font></p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> It all
          started in August 2000 when author and economist Richard Stimson set
          up the Internet forum �FixGov� for
          collaborative writing on reform of government. Many of the participants
          came from another forum called Alternate Culture, and quite a few had
          responded to an invitation at Blue Ear Forum, largely composed of journalists
          and writers from around the world.</font></p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Some 70
          people joined in this project, including members from the United States,
          Canada, Mexico, United Kingdom, Netherlands, Poland, Sweden, India,
          Pakistan, Bangladesh, Mali, Australia, and possibly other countries
          (because email addresses do not always indicate the country). Messages
          were exchanged in English. [<a href="consensus.html"><strong>More ...</strong></a>]</font></p>
      <p align="left">�</p>
      <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">_______________________________________________</font></p>
      <p align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="globalisation.html"><strong><font color="#CC3300">>>> More
                on globalisation ...</font></strong></a></font></p>
      <p align="center">�</p>
      <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Join
            our online discussion on globalisation >>></b></font></p>
      <form method=GET action="http://groups.yahoo.com/subscribe/FixGov">
        <table cellspacing=0 cellpadding=2 border=0 align="center">
          <tr>
            <td colspan=2 align=center>
              <p><b><font color="#CC3300" face="Verdana, Arial, Helvetica, sans-serif" size="2">Subscribe
                    to FixGov</font></b> </p>
              <p>�</p>
            </td>
          </tr>
          <tr>
            <td>
              <input type=text name="user" value="enter email address" size=20>
            </td>
            <td>
              <input type=image border=0 alt="Click here to join FixGov"
       name="Click here to join FixGov"        
       src="join.gif">
            </td>
          </tr>
          <tr align="center">
            <td colspan="2"> </td>
          </tr>
        </table>
        <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">_______________________________________________</font></p>
      </form>
      <div align="center">
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="3"><b><font color="#CC3300" size="5">O</font>ur
          Framework</b></font></p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><font color="#CC3300">We
          all agree that ...</font></b></font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Our purpose
          is to strive for a just, pluralistic and sustainable democracy. </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> We will
            try to fix government & governance in such a way that the fundamental
            freedom of every citizen as well as democratic equality is honoured. </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Every
            citizen has fundamental rights and deserves respect for his opinion,
            because everybody has the capacity to learn, think and formulate
            the "just goals" he feels are true. </font></p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">To establish
            this harmony between the different opinions we need a continuous
            debate with the help of "public reason" (sound arguments and information)
            and aimed at consensus proposals. </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> We view
            society as a collaborative community of reasonable and sensible individuals. </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> This
            collaboration leads to material production, but also to the production
            of ideas, cultures and ways of living. </font></p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Everybody
            should have the same fair chance to express their views and "produce" their
            own alternatives. </font></p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Our society
            is a diversity of communities. These communities share one interest:
            the guarding of just institutions that acknowledge freedom of choice,
            fairness of chances and civil accountability. </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> This
            will all result in a society that is integral and inclusive, with
            people who can collaborate together in a fair way, without loosing
            their self-respect. </font></p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Every
            citizen in our society has the same rights and must have the opportunity
            to make use of this rights. </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> This
            means that liberties, culture, knowledge and wealth must be distributed
            in a fair way. </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> </font><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> The
            inequality that remains must be fair and responsible: not the result
            of lack of democratic freedom and choices. </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">We will
            do everything to abolish the unwanted and unjust inequality in our
            society and we want government to address these inequalities and
            to guard our freedoms. </font> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> </font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> Government
            should be active to practice fairness, but neutral when it comes
            to formulating or manipulating a favoured way of living for the people.
            Groups of people should choose their own way of life.</font> </p>
        <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> The same
            fairness must be established in our community of nations. Our governments
            should help nations that have a political, economical and/or social
            disadvantage.</font> </p>
      </div></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><font color="#FFFFFF"><a href="spirituality.html"><font color="FFFFFF">Spirituality</font></a></font></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><font color="#FFFFFF"><a href="education.html"><font color="#FFFFFF">Education</font></a></font></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><a href="civic.html"><font color="#FFFFFF">Civic
      society</font></a></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><a href="politics.html"><font color="#FFFFFF">Politics</font></a></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><a href="corporations.html"><font color="#FFFFFF">Corporations</font></a></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><a href="money.html"><font color="#FFFFFF">Money</font></a></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><a href="media.html"><font color="#FFFFFF"><b>Media</b></font></a></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="40" bgcolor="#CC3300"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFFFF">_____________</font></b></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><b><a href="download.html"><font color="#FFFFFF">Online
      book</font></a></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><a href="bibliography.html"><font color="#FFFFFF">Literature</font></a></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="30" bgcolor="#CC3300"><font size="2"><b><font face="Verdana, Arial, Helvetica, sans-serif"><a href="links.html"><font color="#FFFFFF">Links</font></a></font></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td height="40" bgcolor="#CC3300"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFFFF">_____________</font></b></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td height="30" bgcolor="#CC3300"><strong><a href="contact.html"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Contact us</font></a></strong></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" height="2000" valign="top" bgcolor="#CC3300"><p>�</p>
        <p><a href="http://groups.yahoo.com/group/FixGov/join" target="top"><img src="join.gif" border=0></a></p>
      <p><a href="http://groups.yahoo.com/group/FixGov/join" target="top"> <b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFFFF">Subscribe to FixGov</font></b></a></p></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125" bgcolor="#CC3300"><div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF"><b><font size="1">� 2004 <a href="http://www.aideon.nl" target="top"><font color="#FFFFFF">aideon</font></a> webdesign</font></b></font></div></td>
      <td width="125" bgcolor="#CCCCCC"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><b>mail
      to <a href="mailto:james@starsfaq.com"><font color="#CC3300">webmaster</font></a></b></font></td>
    </tr>
    <tr bgcolor="#FFFFF4">
      <td width="125">�</td>
      <td width="125">�</td>
      <td width="125">�</td>
      <td width="125">�</td>
      <td width="125">�</td>
      <td width="125">�</td>
    </tr>
  </table>

</body>
</html>
<?php include('/home/1/s/sh/shb1_024/fixgov.org/public_html/include.php') ?>